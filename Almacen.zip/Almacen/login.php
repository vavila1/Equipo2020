	<!-- Login -->
	<div class="container login">
		<div class="row">
			<div class="col s3"></div>
			<div class="col s6">
				<h2 class="center">Inicio de Sesión</h2>
			<form method="POST" action="index.php" enctype="multipart/form-data" autocomplete="off">
				<label>Usuario: </label>
				<input type="text" name="usuario"><br>
				<label>Contraseña: </label>
				<input type="password" name="password"><br>
				<input type="submit" name="enviar" value="enviar">
			</form>
			</div>
		</div>
	</div>
